
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY || '';

export const getFoodRecommendation = async (restaurantName: string, dishName: string) => {
  if (!API_KEY) return "No API key provided.";
  
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a food critic. Provide a very short (2 sentence max) and enticing description or "insider tip" for why a customer should pre-order the ${dishName} at ${restaurantName}. Focus on the "skip the rush" benefit and quality.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "This popular dish is best enjoyed fresh - pre-ordering ensures your table and plate are ready the moment you arrive!";
  }
};

export const getRushAnalysis = async (restaurantName: string) => {
  if (!API_KEY) return null;
  
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Give a one-sentence summary of the typical rush hours and the benefit of pre-booking a seat at ${restaurantName}. Be professional and encouraging.`,
    });
    return response.text;
  } catch (error) {
    return "Peak hours are busy! Save time by pre-ordering your seat now.";
  }
};
